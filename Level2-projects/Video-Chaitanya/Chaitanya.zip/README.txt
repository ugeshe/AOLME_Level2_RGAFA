

To run the code:

0. Run Anaconda Prompt.

1. Navigate to:
     C:\Users\Marios Pattichis\Google Drive
   
2. Run  Generate_Sprite.py using:
     python Generate_Sprite.py BowserFull.png
   Note that the filename can be a .png, .jpg.
   Use left-mouse click to select a point.
   Then use right-mouse click to close the character.
   Look for the result list:
      BowserFull.pickle

3. Switch to Spyder. Inside Spyder, do the following:
     In the lower-right click on "Restarting kernel".
     Right above that, click on "Variable explorer".
     Click on "File explorer" and click on example1.py to open the file.
     
     Note that we specify the center of the sprite.  
        move (relative) and rotate (absolute coordinates) also place the sprite
        flip does not place. It only changes the sprite.
        
        
Exercises:
   1. How can you make it rotate twice as fast?
   2. How can you make it move twice as fast along the rows?
           
        