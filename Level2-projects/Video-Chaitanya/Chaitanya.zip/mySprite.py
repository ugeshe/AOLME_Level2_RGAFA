import aolme2 # Load the library

my_sprite = aolme2.spr()       # Constructor
my_sprite.set_sprite("SuperMario")  # Method: load file
my_sprite.show('SuperMario sprite') # Method: show()
