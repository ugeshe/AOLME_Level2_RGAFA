# -*- coding: utf-8 -*-
"""
Created on Wed May 30 11:33:15 2018

@author: luis
"""

import cv2

bac=cv2.imread("backgroundMario.jpg")